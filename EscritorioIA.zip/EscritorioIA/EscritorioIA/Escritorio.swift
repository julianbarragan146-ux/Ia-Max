import SwiftUI

enum AppID: String, CaseIterable, Identifiable {
    case asistente, notas, calculadora, navegador, archivos, terminal, monitor, calendario, reloj, ajustes
    var id: String { rawValue }
    var titulo: String {
        switch self {
        case .asistente: "Asistente"
        case .notas: "Notas"
        case .calculadora: "Calculadora"
        case .navegador: "Navegador"
        case .archivos: "Archivos"
        case .terminal: "Terminal"
        case .monitor: "Monitor"
        case .calendario: "Calendario"
        case .reloj: "Reloj"
        case .ajustes: "Ajustes"
        }
    }
    var icono: String {
        switch self {
        case .asistente: "sparkles"
        case .notas: "note.text"
        case .calculadora: "plusminus.circle.fill"
        case .navegador: "safari.fill"
        case .archivos: "folder.fill"
        case .terminal: "terminal.fill"
        case .monitor: "chart.bar.fill"
        case .calendario: "calendar"
        case .reloj: "clock.fill"
        case .ajustes: "gearshape.fill"
        }
    }
    var color: Color {
        switch self {
        case .asistente: .purple
        case .notas: .yellow
        case .calculadora: .orange
        case .navegador: .blue
        case .archivos: .cyan
        case .terminal: Color(white: 0.2)
        case .monitor: .red
        case .calendario: .pink
        case .reloj: .indigo
        case .ajustes: .gray
        }
    }
}

@Observable @MainActor
final class Ventana: Identifiable {
    let id = UUID()
    let app: AppID
    var posicion: CGSize
    var z: Double
    init(app: AppID, posicion: CGSize, z: Double) { self.app = app; self.posicion = posicion; self.z = z }
}

@Observable @MainActor
final class Escritorio {
    var ventanas: [Ventana] = []
    var controlAbierto = false
    private var contador = 0.0

    func abrir(_ app: AppID) {
        if let v = ventanas.first(where: { $0.app == app }) { frente(v); return }
        contador += 1
        ventanas.append(Ventana(app: app,
                                posicion: CGSize(width: 16 + contador * 10, height: 50 + contador * 14),
                                z: contador))
    }
    func abrir(nombre: String) -> Bool {
        guard let app = AppID(rawValue: nombre.lowercased()) else { return false }
        abrir(app); return true
    }
    func frente(_ v: Ventana) { contador += 1; v.z = contador }
    func cerrar(_ v: Ventana) { ventanas.removeAll { $0.id == v.id } }
}

struct EscritorioView: View {
    @Environment(Escritorio.self) private var escritorio
    @AppStorage("fondo") private var fondo = 0

    var body: some View {
        ZStack(alignment: .topLeading) {
            LinearGradient(colors: Fondos.colores[min(fondo, Fondos.colores.count - 1)],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            ForEach(escritorio.ventanas) { v in
                VentanaView(ventana: v).zIndex(v.z)
            }
            VStack(spacing: 0) {
                BarraMenu()
                Spacer()
                Dock()
            }
            .zIndex(10_000)
            if escritorio.controlAbierto {
                Color.black.opacity(0.25).ignoresSafeArea()
                    .onTapGesture { withAnimation(.spring) { escritorio.controlAbierto = false } }
                    .zIndex(15_000)
                ControlCentro()
                    .padding(.top, 48)
                    .frame(maxWidth: .infinity)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .zIndex(20_000)
            }
        }
        .gesture(DragGesture().onEnded { g in
            if g.startLocation.y < 120 && g.translation.height > 60 {
                withAnimation(.spring) { escritorio.controlAbierto = true }
            }
        })
    }
}

struct BarraMenu: View {
    @Environment(Escritorio.self) private var escritorio

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: "sparkle")
            Text(escritorio.ventanas.max(by: { $0.z < $1.z })?.app.titulo ?? "Escritorio").bold()
            Spacer()
            Button { withAnimation(.spring) { escritorio.controlAbierto.toggle() } } label: {
                Image(systemName: "slider.horizontal.3")
            }
            .foregroundStyle(.primary)
            TimelineView(.periodic(from: .now, by: 30)) { c in
                Text(c.date, format: .dateTime.weekday(.abbreviated).hour().minute())
            }
        }
        .font(.footnote)
        .padding(.horizontal, 16).padding(.vertical, 8)
        .glassEffect(.regular, in: Capsule())
        .padding(.horizontal, 12)
    }
}

struct VentanaView: View {
    @Environment(Escritorio.self) private var escritorio
    let ventana: Ventana
    @State private var inicio: CGSize?

    var body: some View {
        VStack(spacing: 0) {
            ZStack {
                Text(ventana.app.titulo).font(.footnote.bold())
                HStack(spacing: 8) {
                    Button { withAnimation(.spring) { escritorio.cerrar(ventana) } } label: {
                        Circle().fill(.red).frame(width: 14, height: 14)
                    }
                    Circle().fill(.yellow).frame(width: 14, height: 14)
                    Circle().fill(.green).frame(width: 14, height: 14)
                    Spacer()
                }
            }
            .frame(height: 34).padding(.horizontal, 12)
            .gesture(DragGesture()
                .onChanged { g in
                    if inicio == nil { inicio = ventana.posicion; escritorio.frente(ventana) }
                    let b = inicio ?? .zero
                    ventana.posicion = CGSize(width: b.width + g.translation.width,
                                              height: b.height + g.translation.height)
                }
                .onEnded { _ in inicio = nil })

            Group {
                switch ventana.app {
                case .asistente: AsistenteView()
                case .notas: NotasView()
                case .ajustes: AjustesView()
                case .calculadora: CalculadoraView()
                case .navegador: NavegadorView()
                case .archivos: ArchivosView()
                case .terminal: TerminalView()
                case .monitor: MonitorView()
                case .calendario: CalendarioView()
                case .reloj: RelojView()
                }
            }
        }
        .frame(width: 340, height: 440)
        .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(.white.opacity(0.2)))
        .shadow(radius: 20, y: 8)
        .offset(ventana.posicion)
        .onTapGesture { escritorio.frente(ventana) }
        .transition(.scale.combined(with: .opacity))
    }
}

struct Dock: View {
    @Environment(Escritorio.self) private var escritorio

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 12) {
                ForEach(AppID.allCases) { app in
                    Button {
                        withAnimation(.spring(duration: 0.35, bounce: 0.5)) { escritorio.abrir(app) }
                    } label: {
                        Image(systemName: app.icono)
                            .font(.title3).foregroundStyle(.white)
                            .frame(width: 48, height: 48)
                            .background(app.color.gradient, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                            .overlay(alignment: .bottom) {
                                if escritorio.ventanas.contains(where: { $0.app == app }) {
                                    Circle().fill(.white).frame(width: 4, height: 4).offset(y: 6)
                                }
                            }
                    }
                }
            }
            .padding(.horizontal, 10).padding(.vertical, 10)
        }
        .frame(height: 76)
        .frame(maxWidth: 370)
        .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
        .padding(.horizontal, 8).padding(.bottom, 8)
    }
}
