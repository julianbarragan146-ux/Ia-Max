import SwiftUI

struct AsistenteView: View {
    @Environment(Asistente.self) private var asistente

    var body: some View {
        @Bindable var a = asistente
        VStack(spacing: 0) {
            if let aviso = a.aviso {
                Text(aviso).font(.caption).foregroundStyle(.orange).padding(8)
            }
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 8) {
                        ForEach(a.mensajes) { m in
                            Text(m.texto)
                                .padding(10)
                                .background(m.esUsuario ? Color.blue : Color.gray.opacity(0.3),
                                            in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                                .frame(maxWidth: .infinity, alignment: m.esUsuario ? .trailing : .leading)
                                .id(m.id)
                        }
                        if a.pensando { ProgressView() }
                    }
                    .padding(10)
                }
                .onChange(of: a.mensajes.count) { _, _ in
                    if let u = a.mensajes.last { withAnimation { proxy.scrollTo(u.id) } }
                }
            }
            HStack {
                TextField("Escribe o habla…", text: $a.borrador)
                    .textFieldStyle(.roundedBorder)
                Button { Task { await a.alternarMicrofono() } } label: {
                    Image(systemName: a.escuchando ? "waveform.circle.fill" : "mic.circle.fill").font(.title)
                }
                Button {
                    let t = a.borrador; a.borrador = ""
                    Task { await a.enviar(t) }
                } label: { Image(systemName: "arrow.up.circle.fill").font(.title) }
            }
            .padding(8)
        }
    }
}

struct NotasView: View {
    @AppStorage("notas") private var notas = ""

    var body: some View {
        TextEditor(text: $notas)
            .scrollContentBackground(.hidden)
            .padding(8)
            .background(Color.yellow.opacity(0.12))
    }
}

struct AjustesView: View {
    @Environment(Asistente.self) private var asistente
    @AppStorage("fondo") private var fondo = 0

    var body: some View {
        @Bindable var a = asistente
        Form {
            Picker("Fondo", selection: $fondo) {
                ForEach(Fondos.nombres.indices, id: \.self) { Text(Fondos.nombres[$0]).tag($0) }
            }
            Toggle("Responder en voz alta", isOn: $a.hablar)
            Section("Estado") { Text(a.aviso ?? "Apple Intelligence disponible") }
        }
        .scrollContentBackground(.hidden)
    }
}
