import SwiftUI
import WebKit
import UIKit

enum Fondos {
    static let nombres = ["Aurora", "Océano", "Bosque", "Noche"]
    static let colores: [[Color]] = [
        [.indigo, .purple, .pink.opacity(0.8), .orange.opacity(0.7)],
        [.blue, .cyan, .teal],
        [.green, .mint, .teal],
        [.black, .indigo.opacity(0.6), .purple.opacity(0.4)]
    ]
}

// MARK: - Calculadora

struct CalculadoraView: View {
    @State private var pantalla = "0"
    @State private var acumulado: Double?
    @State private var operacion: String?
    @State private var nuevo = true
    private let filas = [["C", "±", "%", "÷"], ["7", "8", "9", "×"], ["4", "5", "6", "−"], ["1", "2", "3", "+"], ["0", ".", "="]]

    var body: some View {
        VStack(spacing: 8) {
            Spacer()
            Text(pantalla).font(.system(size: 44, weight: .light)).lineLimit(1).minimumScaleFactor(0.5)
                .frame(maxWidth: .infinity, alignment: .trailing)
            Grid(horizontalSpacing: 8, verticalSpacing: 8) {
                ForEach(filas, id: \.self) { fila in
                    GridRow {
                        ForEach(fila, id: \.self) { t in
                            Button { pulsar(t) } label: {
                                Text(t).font(.title2).frame(maxWidth: .infinity, minHeight: 46)
                                    .background(["÷", "×", "−", "+", "="].contains(t) ? Color.orange : Color.gray.opacity(0.35),
                                                in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                            }
                            .foregroundStyle(.white)
                            .gridCellColumns(t == "0" ? 2 : 1)
                        }
                    }
                }
            }
        }
        .padding(10)
    }

    private func formato(_ r: Double) -> String {
        if r.isNaN { return "Error" }
        return r == r.rounded() && abs(r) < 1e12 ? String(Int(r)) : String(r)
    }

    private func calcular() {
        guard let v = Double(pantalla) else { return }
        if let a = acumulado, let op = operacion, !nuevo {
            let r: Double
            switch op {
            case "+": r = a + v
            case "−": r = a - v
            case "×": r = a * v
            default: r = v == 0 ? .nan : a / v
            }
            pantalla = formato(r)
            acumulado = r
        } else {
            acumulado = v
        }
    }

    private func pulsar(_ t: String) {
        switch t {
        case "C": pantalla = "0"; acumulado = nil; operacion = nil; nuevo = true
        case "±": if let v = Double(pantalla) { pantalla = formato(-v) }
        case "%": if let v = Double(pantalla) { pantalla = formato(v / 100) }
        case "÷", "×", "−", "+": calcular(); operacion = t; nuevo = true
        case "=": calcular(); operacion = nil; nuevo = true
        case ".":
            if nuevo { pantalla = "0."; nuevo = false } else if !pantalla.contains(".") { pantalla += "." }
        default:
            pantalla = (nuevo || pantalla == "0") ? t : pantalla + t
            nuevo = false
        }
    }
}

// MARK: - Navegador

struct WebView: UIViewRepresentable {
    let url: URL
    final class Coordinator { var cargada: URL? }
    func makeCoordinator() -> Coordinator { Coordinator() }
    func makeUIView(context: Context) -> WKWebView { WKWebView() }
    func updateUIView(_ v: WKWebView, context: Context) {
        if context.coordinator.cargada != url {
            context.coordinator.cargada = url
            v.load(URLRequest(url: url))
        }
    }
}

struct NavegadorView: View {
    @State private var texto = ""
    @State private var url = URL(string: "https://duckduckgo.com")!

    var body: some View {
        VStack(spacing: 0) {
            TextField("Buscar o escribir dirección", text: $texto)
                .textFieldStyle(.roundedBorder)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .keyboardType(.webSearch)
                .padding(8)
                .onSubmit(ir)
            WebView(url: url)
        }
    }

    private func ir() {
        let t = texto.trimmingCharacters(in: .whitespaces)
        if t.contains("."), !t.contains(" "), let u = URL(string: t.hasPrefix("http") ? t : "https://" + t) {
            url = u
        } else if let q = t.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
                  let u = URL(string: "https://duckduckgo.com/?q=" + q) {
            url = u
        }
    }
}

// MARK: - Archivos

struct ArchivosView: View {
    @State private var archivos: [URL] = []

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Documentos").font(.headline)
                Spacer()
                Button("Nuevo", systemImage: "plus") { crear() }
            }
            .padding(10)
            List {
                ForEach(archivos, id: \.self) { Label($0.lastPathComponent, systemImage: "doc") }
                    .onDelete { idx in
                        idx.forEach { try? FileManager.default.removeItem(at: archivos[$0]) }
                        cargar()
                    }
            }
            .scrollContentBackground(.hidden)
        }
        .onAppear(perform: cargar)
    }

    private func cargar() {
        archivos = (try? FileManager.default.contentsOfDirectory(at: .documentsDirectory, includingPropertiesForKeys: nil)) ?? []
    }

    private func crear() {
        let u = URL.documentsDirectory.appending(path: "Archivo \(Int(Date().timeIntervalSince1970)).txt")
        try? "Hola desde EscritorioIA".write(to: u, atomically: true, encoding: .utf8)
        cargar()
    }
}

// MARK: - Terminal (simulada, dentro de la carpeta Documentos de la app)

struct TerminalView: View {
    @State private var salida = "EscritorioIA Terminal. Escribe 'ayuda'.\n"
    @State private var entrada = ""
    private let fm = FileManager.default
    private let raiz = URL.documentsDirectory

    var body: some View {
        VStack(spacing: 0) {
            ScrollView {
                Text(salida).frame(maxWidth: .infinity, alignment: .leading).padding(8)
            }
            HStack {
                Text("$")
                TextField("", text: $entrada)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .onSubmit(ejecutar)
            }
            .padding(8)
        }
        .font(.system(.footnote, design: .monospaced))
        .foregroundStyle(.green)
        .background(Color.black.opacity(0.85))
    }

    private func ejecutar() {
        let linea = entrada
        entrada = ""
        salida += "$ \(linea)\n"
        let partes = linea.split(separator: " ", maxSplits: 1).map(String.init)
        guard let cmd = partes.first else { return }
        let arg = partes.count > 1 ? partes[1] : ""
        let u = raiz.appending(path: (arg as NSString).lastPathComponent)
        switch cmd {
        case "ayuda": salida += "ls, cat <f>, touch <f>, rm <f>, echo <t>, date, clear\n"
        case "ls": salida += ((try? fm.contentsOfDirectory(atPath: raiz.path)) ?? []).joined(separator: "\n") + "\n"
        case "cat": salida += ((try? String(contentsOf: u, encoding: .utf8)) ?? "no existe") + "\n"
        case "touch": fm.createFile(atPath: u.path, contents: nil)
        case "rm": salida += ((try? fm.removeItem(at: u)) == nil ? "no se pudo borrar\n" : "")
        case "echo": salida += arg + "\n"
        case "date": salida += Date().formatted() + "\n"
        case "clear": salida = ""
        default: salida += "comando no encontrado: \(cmd)\n"
        }
    }
}

// MARK: - Monitor del sistema

struct MonitorView: View {
    var body: some View {
        TimelineView(.periodic(from: .now, by: 2)) { _ in
            Form {
                LabeledContent("Sistema", value: "\(UIDevice.current.systemName) \(UIDevice.current.systemVersion)")
                LabeledContent("Batería", value: bateria)
                LabeledContent("Memoria RAM", value: ByteCountFormatter.string(fromByteCount: Int64(ProcessInfo.processInfo.physicalMemory), countStyle: .memory))
                LabeledContent("Almacenamiento libre", value: libre)
                LabeledContent("Temperatura", value: termico)
            }
            .scrollContentBackground(.hidden)
        }
        .onAppear { UIDevice.current.isBatteryMonitoringEnabled = true }
    }

    private var bateria: String {
        let n = UIDevice.current.batteryLevel
        return n < 0 ? "N/D" : "\(Int(n * 100)) %"
    }

    private var libre: String {
        let v = try? URL.documentsDirectory.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
        return ByteCountFormatter.string(fromByteCount: v?.volumeAvailableCapacityForImportantUsage ?? 0, countStyle: .file)
    }

    private var termico: String {
        switch ProcessInfo.processInfo.thermalState {
        case .nominal: "Normal"
        case .fair: "Templada"
        case .serious: "Alta"
        case .critical: "Crítica"
        @unknown default: "Desconocida"
        }
    }
}
